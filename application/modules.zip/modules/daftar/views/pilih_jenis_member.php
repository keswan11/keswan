<div class="box-body">
	<div class="row" align="center">
		<div class="col-lg-6">
			<a href="<?php echo site_url('daftar/perorangan'); ?>" title="Perorangan" class="btn btn-lg btn-danger"><i class="fa fa-user"></i> Perorangan</a>
		</div>
		<div class="col-lg-6">
			<a href="<?php echo site_url('daftar/instansi'); ?>" title="Instansi" class="btn btn-lg btn-info"><i class="fa fa-building"></i> Instansi</a>
		</div>
	</div>
</div>