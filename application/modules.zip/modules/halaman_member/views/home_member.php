<section class="content">
  <div class="box box-primary">
    <div class="box-header">
      <h3><?php echo $title;?></h3>
    </div>

    <div class="box-body">
      <div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3>0</h3>

              <p>List Surat Ijin</p>
            </div>
            <div class="icon">
              <i class="fa fa-file"></i>
            </div>
            <a href="#" class="small-box-footer">Detail <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

      </div>
      <!-- /.row -->
    </div>
  </div>
</section>

