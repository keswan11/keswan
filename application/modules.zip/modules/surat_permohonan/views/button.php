<html>
<head>
	<title>Download PDF</title>
</head>
<body>
<table border="0" align="center">
<tr>
	<td width="20%"><a href="<?php echo base_url('surat_permohonan/Surat_permohonan/sipp_drh_wni');?>"><button>Cetak SIPP INI DI MEMBER UNTUK PENGAJUAN ATAR PKB INSEMINATOR KESWA</button></a><br><br></td>
</tr>
<tr>
	<td width="20%"><a href="<?php echo base_url('surat_permohonan/Surat_permohonan/sip_drh_wni');?>"><button>Cetak SIP DRH WNI INI DI MEMBER DRH DAN DRH KUDA</button></a><br><br></td>
</tr>
<tr>
	<td><a href="<?php echo base_url('surat_permohonan/Surat_permohonan/sivet');?>"><button>Cetak SIVET</button></a><br><br></td>
</tr>
<tr>
	<td><a href="<?php echo base_url('surat_permohonan/Surat_permohonan/sipp_atr');?>"><button>Cetak SIPP ATR</button></a><br><br></td>
</tr>
<tr>
	<td><a href="<?php echo base_url('surat_permohonan/Surat_permohonan/sipp_pkb');?>"><button>Cetak SIPP PKB</button></a><br><br></td>
</tr>
<tr>
	<td><a href="<?php echo base_url('surat_permohonan/Surat_permohonan/sipp_inseminator');?>"><button>Cetak SIPP INSEMINATOR</button></a><br><br></td>
</tr>
<tr>
	<td><a href="<?php echo base_url('surat_permohonan/Surat_permohonan/sipp_keswan');?>"><button>Cetak SIPP KESWAN</button></a><br><br></td>
</tr>
<tr>
	<td><a href="<?php echo base_url('surat_permohonan/Surat_permohonan/sip_drh');?>"><button>Cetak SIP DRH INI DI OPERATOR</button></a><br><br></td>
</tr>
<tr>
	<td><a href="<?php echo base_url('surat_permohonan/Surat_permohonan/sip_konsultasi');?>"><button>Cetak SIP KONSULTASI</button></a><br><br></td>
</tr>
<tr>
	<td><a href="<?php echo base_url('surat_permohonan/Surat_permohonan/sip_keterangan_konsultasi');?>"><button>Cetak SIP KETERANGAN KONSULTASI</button></a><br><br></td>
</tr>
<tr>
	<td><a href="<?php echo base_url('surat_permohonan/Surat_permohonan/sip_kuda');?>"><button>Cetak SIPKUDA</button></a><br><br></td>
</tr>

</table>
</body>
</html>