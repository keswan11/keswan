<html>
<head>
	<title>
		
	</title>
	<style type="text/css">
	.font10{
		font-size: 10pt;
		font-family: : Times;
	}

	.font14{
		font-size: 14pt;
		font-family: : Times;
	}
	.font6{
		font-size: 8pt;
		font-family: : Times;
	}
	.font11{
		font-size: 11pt;
		font-family: : Times;
	}
</style>
</head><body>
	<table width="100%" class="font10">
		<tr>
			<td>&nbsp;&nbsp;&nbsp;LAMPIRAN I PERATURAN MENTERI PERTANIAN REPUBLIK INDONESIA</td>
		</tr>
	</table>
<table align="center" width="90%" class="font10">
	
	<tr align="center">
		<td colspan="4"><br><b>FASILITAS MINIMAL PELAYANAN KESEHATAN HEWAN AMBULATORI</b><br></td>
	</tr>
</table>
	<table align="center" width="90%" class="font10">
		<tr>
			<td><b>&nbsp;&nbsp;Fasilitas</b></td>
		</tr>
	</table>
	<table align="center" width="90%" border="1" cellspacing="0" class="font10">
	<tr align="center">
		<td width="5%"><b>No</b></td>
		<td width="40%"><b>Nama Peralatan</b></td>
		<td><b>Jumlah</b></td>
		<td><b>Keterangan</b></td>
	</tr>
	<tr>
		<td><p align="center">1</p></td>
		<td>&nbsp;Kendaraan dan Tulisan <br>&nbsp;“Jasa Kesehatan Hewan Ambulatori”</p></td>
		<td></td>
		<td></td>
	</tr>
</table>

	<table align="center" width="90%" class="font10">
		<tr>
			<td><b>&nbsp;&nbsp;Peralatan dalam Kendaraan<br>&nbsp;&nbsp;&nbsp;&nbsp;a. Pendiagnosaan</b></td>
		</tr>
	</table>
	<table align="center" width="90%" border="1" cellspacing="0" class="font10">
	<tr align="center">
		<td width="5%"><b>No</b></td>
		<td width="40%"><b>Nama Peralatan</b></td>
		<td><b>Jumlah</b></td>
		<td><b>Keterangan</b></td>
	</tr>
	<tr>
		<td><p align="center">1</p></td>
		<td>&nbsp;Termometer</td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td><p align="center">2</p></td>
		<td>&nbsp;Stetoskop</td>
		<td></td>
		<td></td>
	</tr>
</table>

	<table align="center" width="90%" class="font10">
		<tr>
			<td><b>&nbsp;&nbsp;&nbsp;&nbsp;b. Tindakan</b></td>
		</tr>
	</table>
	<table align="center" width="90%" border="1" cellspacing="0" class="font10">
	<tr align="center">
		<td width="5%"><b>No</b></td>
		<td width="40%"><b>Nama Peralatan</b></td>
		<td><b>Jumlah</b></td>
		<td><b>Keterangan</b></td>
	</tr>
	<tr>
		<td><p align="center">1</p></td>
		<td>&nbsp;Disposible syringe</td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td><p align="center">2</p></td>
		<td>&nbsp;Disposible needle</td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td><p align="center">3</p></td>
		<td>&nbsp;Infusion set</td>
		<td></td>
		<td></td>
	</tr>
</table>

	<table align="center" width="90%" class="font10">
		<tr>
			<td><b>&nbsp;&nbsp;&nbsp;&nbsp;c. Operasi minor</b></td>
		</tr>
	</table>
	<table align="center" width="90%" border="1" cellspacing="0" class="font10">
	<tr align="center">
		<td width="5%"><b>No</b></td>
		<td width="40%"><b>Nama Peralatan</b></td>
		<td><b>Jumlah</b></td>
		<td><b>Keterangan</b></td>
	</tr>
	<tr>
		<td><p align="center">1</p></td>
		<td>&nbsp;Gunting bengkok dan lurus</td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td><p align="center">2</p></td>
		<td>&nbsp;Arteri klem</td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td><p align="center">3</p></td>
		<td>&nbsp;Pinset</td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td><p align="center">4</p></td>
		<td>&nbsp;Scalpel</td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td><p align="center">5</p></td>
		<td>&nbsp;Kidney Tray</td>
		<td></td>
		<td></td>
	</tr>
</table>

	<table align="center" width="90%" class="font10">
		<tr>
			<td><b>&nbsp;&nbsp; Perlengkapan</b></td>
		</tr>
	</table>
	<table align="center" width="90%" border="1" cellspacing="0" class="font10">
	<tr align="center">
		<td width="5%"><b>No</b></td>
		<td width="40%"><b>Nama Peralatan</b></td>
		<td><b>Jumlah</b></td>
		<td><b>Keterangan</b></td>
	</tr>
	<tr>
		<td><p align="center">1</p></td>
		<td>&nbsp;Kartu nama</td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td><p align="center">2</p></td>
		<td>&nbsp;Buku resep</td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td><p align="center">3</p></td>
		<td>&nbsp;Rekam medis</td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td><p align="center">4</p></td>
		<td>&nbsp;Baju praktik</td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td><p align="center">5</p></td>
		<td>&nbsp;Baju bedah</td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td><p align="center">6</p></td>
		<td>&nbsp;Pengukur bobot badan</td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td><p align="center">7</p></td>
		<td>&nbsp;Tempat penyimpanan obat dan alat</td>
		<td></td>
		<td></td>
	</tr>
</table>

	<table align="center" width="90%" class="font10">
		<tr>
			<td><b>&nbsp;&nbsp; Obat-obatan</b></td>
		</tr>
	</table>
	<table align="center" width="90%" border="1" cellspacing="0" class="font10">
	<tr align="center">
		<td width="5%"><b>No</b></td>
		<td width="40%"><b>Nama Peralatan</b></td>
		<td><b>Jumlah</b></td>
		<td><b>Keterangan</b></td>
	</tr>
	<tr>
		<td><p align="center">1</p></td>
		<td>&nbsp;Alkohol</p></td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td><p align="center">2</p></td>
		<td>&nbsp;Antiseptik</td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td><p align="center">3</p></td>
		<td>&nbsp;Antibiotik</td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td><p align="center">4</p></td>
		<td>&nbsp;Antipiretik</td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td><p align="center">5</p></td>
		<td>&nbsp;Analgesik</td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td><p align="center">6</p></td>
		<td>&nbsp;Antihistamina</td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td><p align="center">7</p></td>
		<td>&nbsp;Anti parasit</td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td><p align="center">8</p></td>
		<td>&nbsp;Lidocain</td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td><p align="center">9</p></td>
		<td>&nbsp;Sedativa</td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td><p align="center">10</p></td>
		<td>&nbsp;Cairan infus (minimal NaCl dan LRL)</td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td><p align="center">11</p></td>
		<td>&nbsp;Vitamin dan mineral</td>
		<td></td>
		<td></td>
	</tr>
</table>
<br><br><br>
<table align="center" width="90%"  cellspacing="0" class="font10">
	<tr align="center">
		<td width="5%"></td>
		<td width="40%"></td>
		<td width="20%"></td>
		<td align="center">MENTERI PERTANIAN<br>
REPUBLIK INDONESIA,<br><br><br><br>(&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;)</td>

	</tr>
</table>
</body></html>