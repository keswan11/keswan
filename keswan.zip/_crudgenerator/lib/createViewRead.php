<!--
Author : Hari Prasetyo
Website : harviacode.com
Create Date : 08/05/2015

HMVC Modified By
====================
Author : Raessa Fathul Alim
Website : http://mahasiswapoltek.org
Create Date : 22/06/2015

You may edit this code, but please do not remove original information. Thanks :D
-->
<?php

$path = "../application/modules/".$table."/views/" . $read_file;
$dirpath = "../application/modules/".$table."/views/";
mkdir($dirpath,0755,TRUE);

$createRead = fopen($path, "w") or die("Unable to open file!");

$result2 = mysql_query("SELECT COLUMN_NAME,COLUMN_KEY FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='$database' AND TABLE_NAME='$table' AND COLUMN_KEY = 'PRI'");
$row = mysql_fetch_assoc($result2);
$primary = $row['COLUMN_NAME'];

$string = "<!doctype html>
<html>
    <head>
        <title>".ucfirst($table)."</title>
        <link rel=\"stylesheet\" href=\"<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>\"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style=\"margin-top:0px\">".ucfirst($table)." Read</h2>
        <table class=\"table\">";
$result2 = mysql_query("SELECT COLUMN_NAME,DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='$database' AND TABLE_NAME='$table' AND COLUMN_KEY <> 'PRI'");
if (mysql_num_rows($result2) > 0)
{
    while ($row1 = mysql_fetch_assoc($result2))
    {
        $string .= "\n\t    <tr><td><strong>".ucwords($row1["COLUMN_NAME"])."</strong></td><td><?php echo \": \".$".$row1["COLUMN_NAME"]."; ?></td></tr>";
    }
}
$string .= "\n\t    <tr><td></td><td><a href=\"<?php echo site_url('".$controller."') ?>\" class=\"btn btn-default\">Cancel</button></td></tr>";
$string .= "\n\t</table>
    </body>
</html>";


fwrite($createRead, $string);
fclose($createRead);

$read_res = "<p>" . $path . "</p>";
?>
