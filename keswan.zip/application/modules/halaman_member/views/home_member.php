<section class="content">
  <div class="box box-primary">
    <div class="box-header">
      <h3><?php echo $title;?></h3>
    </div>

    <div class="box-body">
           <h4>Selamat Datang di halaman member!</h4>
      <!-- /.row -->
    </div>
  </div>
</section>

