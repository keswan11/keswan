<html>
<head>
  <title>
    
  </title>
  <style type="text/css">
  .font10{
    font-size: 10pt;
    font-family: : Times;
  }

  .font14{
    font-size: 14pt;
    font-family: : Times;
  }
  .font6{
    font-size: 8pt;
    font-family: : Times;
  }
  .font11{
    font-size: 11pt;
    font-family: : Times;
  }
</style>
</head><body>
  <table width="100%" class="font10">
    <tr>
      <td>&nbsp;&nbsp;&nbsp;LAMPIRAN</td>
    </tr>
  </table>
<table align="center" width="90%" class="font10">
  
  <tr align="center">
    <td colspan="4"><br><b>FASILITAS PELAYANAN KLINIK HEWAN</b><br></td>
  </tr>
</table>
  <table align="center" width="90%" class="font10">
    <tr>
      <td><b>&nbsp;&nbsp;Fasilitas</b></td>
    </tr>
  </table>
  <table align="center" width="90%" border="1" cellspacing="0" class="font10">
  <tr align="center">
    <td width="5%"><b>No</b></td>
    <td width="40%"><b>Nama Peralatan</b></td>
    <td><b>Jumlah</b></td>
    <td><b>Keterangan</b></td>
  </tr>
  <tr>
    <td><p align="center">1</p></td>
    <td>&nbsp;Papan Nama</p></td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">2</p></td>
    <td>&nbsp;Ruang praktik </p></td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">3</p></td>
    <td>&nbsp;Ruang administrasi </p></td>
    <td></td>
    <td></td>
  </tr>
   <tr>
    <td><p align="center">4</p></td>
    <td>&nbsp;Ruang tunggu </p></td>
    <td></td>
    <td></td>
  </tr>
   <tr>
    <td><p align="center">5</p></td>
    <td>&nbsp;Ruang  observasi/rawat inap 1) </p></td>
    <td></td>
    <td></td>
  </tr>
   <tr>
    <td><p align="center">6</p></td>
    <td>&nbsp;Ruang  operasi </p></td>
    <td></td>
    <td></td>
  </tr>
   <tr>
    <td><p align="center">7</p></td>
    <td>&nbsp;Ruang preparasi </p></td>
    <td></td>
    <td></td>
  </tr>
</table>

  <table align="center" width="90%" class="font10">
    <tr>
      <td><b>&nbsp;&nbsp;Peralatan dalam Kendaraan<br>&nbsp;&nbsp;&nbsp;&nbsp;a. Pendiagnosaan</b></td>
    </tr>
  </table>
  <table align="center" width="90%" border="1" cellspacing="0" class="font10">
  <tr align="center">
    <td width="5%"><b>No</b></td>
    <td width="40%"><b>Nama Peralatan</b></td>
    <td><b>Jumlah</b></td>
    <td><b>Keterangan</b></td>
  </tr>
  <tr>
    <td><p align="center">1</p></td>
    <td>&nbsp;Termometer</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">2</p></td>
    <td>&nbsp;Stetoskop</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">5</p></td>
    <td>&nbsp;Percusi hammer</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">4</p></td>
    <td>&nbsp;Opthalmoscope</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">5</p></td>
    <td>&nbsp;Otoscope</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">6</p></td>
    <td>&nbsp;Doppler atau USG</td>
    <td></td>
    <td></td>
  </tr>
</table>

  <table align="center" width="90%" class="font10">
    <tr>
      <td><b>&nbsp;&nbsp;&nbsp;&nbsp;b. Peralatan laboratorium</b></td>
    </tr>
  </table>
  <table align="center" width="90%" border="1" cellspacing="0" class="font10">
  <tr align="center">
    <td width="5%"><b>No</b></td>
    <td width="40%"><b>Nama Peralatan</b></td>
    <td><b>Jumlah</b></td>
    <td><b>Keterangan</b></td>
  </tr>
  <tr>
    <td><p align="center">1</p></td>
    <td>&nbsp;Mikroskop binocular</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">2</p></td>
    <td>&nbsp;Centrifuge</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">3</p></td>
    <td>&nbsp;Alat periksa darah</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">4</p></td>
    <td>&nbsp;Alat urinalisis</td>
    <td></td>
    <td></td>
  </tr>
</table>

  <table align="center" width="90%" class="font10">
    <tr>
      <td><b>&nbsp;&nbsp;&nbsp;&nbsp;c. Tindakan</b></td>
    </tr>
  </table>
  <table align="center" width="90%" border="1" cellspacing="0" class="font10">
  <tr align="center">
    <td width="5%"><b>No</b></td>
    <td width="40%"><b>Nama Peralatan</b></td>
    <td><b>Jumlah</b></td>
    <td><b>Keterangan</b></td>
  </tr>
  <tr>
    <td><p align="center">1</p></td>
    <td>&nbsp;Disposible syringe</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">2</p></td>
    <td>&nbsp;Disposible needle</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">3</p></td>
    <td>&nbsp;Infusion set</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">4</p></td>
    <td>&nbsp;Feeding force catheter</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">5</p></td>
    <td>&nbsp;Urin Catheter</td>
    <td></td>
    <td></td>
  </tr>
</table>
  <table align="center" width="90%" class="font10">
    <tr>
      <td><b>&nbsp;&nbsp;&nbsp;&nbsp;d. Bedah mayor</b></td>
    </tr>
  </table>
  <table align="center" width="90%" border="1" cellspacing="0" class="font10">
  <tr align="center">
    <td width="5%"><b>No</b></td>
    <td width="40%"><b>Nama Peralatan</b></td>
    <td><b>Jumlah</b></td>
    <td><b>Keterangan</b></td>
  </tr>
  <tr>
    <td><p align="center">1</p></td>
    <td>&nbsp;Gunting bengkok dan lurus</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">2</p></td>
    <td>&nbsp;Arteri klem</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">3</p></td>
    <td>&nbsp;Pinset</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">4</p></td>
    <td>&nbsp;Scalpel</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">5</p></td>
    <td>&nbsp;Kidney Tray</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">6</p></td>
    <td>&nbsp;Benang Operasi</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">7</p></td>
    <td>&nbsp;Tabung Oksigen lengkap</td>
    <td></td>
    <td></td>
  </tr>
</table>

  <table align="center" width="90%" class="font10">
    <tr>
      <td><b>&nbsp;&nbsp; Perlengkapan</b></td>
    </tr>
  </table>
  <table align="center" width="90%" border="1" cellspacing="0" class="font10">
  <tr align="center">
    <td width="5%"><b>No</b></td>
    <td width="40%"><b>Nama Peralatan</b></td>
    <td><b>Jumlah</b></td>
    <td><b>Keterangan</b></td>
  </tr>
  <tr>
    <td><p align="center">1</p></td>
    <td>&nbsp;Kartu nama</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">2</p></td>
    <td>&nbsp;Buku resep</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">3</p></td>
    <td>&nbsp;Rekam medis</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">4</p></td>
    <td>&nbsp;Baju praktik</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">5</p></td>
    <td>&nbsp;Baju bedah</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">6</p></td>
    <td>&nbsp;Pengukur bobot badan</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">7</p></td>
    <td>&nbsp;Meja konsultasi/administrasi</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">8</p></td>
    <td>&nbsp;Meja periksa </td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">9</p></td>
    <td>&nbsp;Tempat penyimpanan obat dan alat </td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">10</p></td>
    <td>&nbsp;Cooler box / lemari es </td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">11</p></td>
    <td>&nbsp;Meja bedah </td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">12</p></td>
    <td>&nbsp;Lampu operasi </td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">13</p></td>
    <td>&nbsp;Tiang infus </td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">14</p></td>
    <td>&nbsp;X-Ray Viewer </td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">15</p></td>
    <td>&nbsp;Baskom stainless </td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">16</p></td>
    <td>&nbsp;Container  stainless </td>
    <td></td>
    <td></td>
  </tr>
</table>

  <table align="center" width="90%" class="font10">
    <tr>
      <td><b>&nbsp;&nbsp; Instalasi Farmasi yang memiliki obat-obatan minimal:</b></td>
    </tr>
  </table>
  <table align="center" width="90%" border="1" cellspacing="0" class="font10">
  <tr align="center">
    <td width="5%"><b>No</b></td>
    <td width="40%"><b>Nama Peralatan</b></td>
    <td><b>Jumlah</b></td>
    <td><b>Keterangan</b></td>
  </tr>
  <tr>
    <td><p align="center">1</p></td>
    <td>&nbsp;Alkohol</p></td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">2</p></td>
    <td>&nbsp;Antiseptik</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">3</p></td>
    <td>&nbsp;Antibiotik</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">4</p></td>
    <td>&nbsp;Anti peuretik/analgesik</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">5</p></td>
    <td>&nbsp;Anti histamin</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">6</p></td>
    <td>&nbsp;Anti parasit</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">7</p></td>
    <td>&nbsp;Lidocain</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">8</p></td>
    <td>&nbsp;Sedativa</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">9</p></td>
    <td>&nbsp;Cairan  infus (minimal NaCl dan LRL)</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">10</p></td>
    <td>&nbsp;Vitamin dan mineral</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><p align="center">11</p></td>
    <td>&nbsp;Vaksin</td>
    <td></td>
    <td></td>
  </tr>
</table>

<table>
  <tr>
    <td>
      Catatan :<br>
1)  kapasitas maksimal 10 ekor hewan kecil

    </td>
  </tr>
</table>

</body></html>