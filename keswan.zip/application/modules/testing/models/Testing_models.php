<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Testing_models extends CI_Model {

	public function getModels()
		{

		}	

}

/* End of file Testing_models.php */
/* Location: ./application/modules/testing/models/Testing_models.php */