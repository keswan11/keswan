<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h1><?php echo $data; ?></h1>
</body>
</html>