<!DOCTYPE html>
<html>
<head>
	<title>Testing View</title>
</head>
<body>
	This Is Testing View!<br>
	<?php echo $testmodel ?>
	<br>
	<?php echo base_url(); ?>
</body>
</html>