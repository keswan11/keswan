
    
    /*
        Loader
    */
    $(".loader-img").fadeOut();
    $(".loader").delay(1500).fadeOut("slow");